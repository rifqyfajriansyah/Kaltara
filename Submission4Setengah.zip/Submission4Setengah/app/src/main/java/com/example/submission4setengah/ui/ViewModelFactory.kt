package com.example.submission4setengah.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.submission4setengah.data.DataRepo
import com.example.submission4setengah.ui.login.MainViewModel
import com.example.submission4setengah.data.pref.UserStore
import com.example.submission4setengah.data.pref.dataStore
import com.example.submission4setengah.di.Injection
import com.example.submission4setengah.ui.add.AddViewModel
import com.example.submission4setengah.ui.detail.DetailViewModel
import com.example.submission4setengah.ui.menu.MenuViewModel

class ViewModelFactory private constructor(private val repo: DataRepo, private val pref:UserStore) : ViewModelProvider.NewInstanceFactory() {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(repo, pref) as T
        }

        if (modelClass.isAssignableFrom(MenuViewModel::class.java)) {
            return MenuViewModel(repo, pref) as T
        }

        if (modelClass.isAssignableFrom(DetailViewModel::class.java)) {
            return DetailViewModel(repo) as T
        }

        if (modelClass.isAssignableFrom(AddViewModel::class.java)) {
            return AddViewModel(repo) as T
        }

        throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
    }

    companion object {
        @Volatile
        private var instance: ViewModelFactory? = null
        fun getInstance(context: Context): ViewModelFactory =
            instance ?: synchronized(this) {
                instance ?: ViewModelFactory(Injection.provideData(context),
                    UserStore.getInstance(context.applicationContext.dataStore))
            }.also { instance = it }
    }
}