package com.example.submission4setengah.ui.menu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.submission4setengah.R
import com.example.submission4setengah.data.DataResult
import com.example.submission4setengah.data.remote.response.DetailStory
import com.example.submission4setengah.databinding.ActivityMenuBinding
import com.example.submission4setengah.ui.ViewModelFactory
import com.example.submission4setengah.ui.add.AddActivity
import com.example.submission4setengah.ui.detail.DetailActivity
import com.example.submission4setengah.ui.login.MainActivity

class MenuActivity : AppCompatActivity() {

    private var _binding: ActivityMenuBinding? = null
    private val binding get() = _binding
    private lateinit var view: View

    private val vm by viewModels<MenuViewModel> {
        ViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityMenuBinding.inflate(layoutInflater)
        view = binding?.root!!
        setContentView(view)

        val layoutManager = LinearLayoutManager(this)
        binding?.menuRec?.layoutManager = layoutManager


        getListData()

        binding?.btMenuAdd?.setOnClickListener{
            val intent = Intent(this, AddActivity::class.java)
            startActivity(intent)
        }

        vm.getLogin().observe(this){isLogin : Boolean ->
            if(!isLogin){
                val intent = Intent(this, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
                finish()

            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menumain, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_setting -> {
                startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS))
            }
            R.id.action_logout ->{
                vm.logout()
            }

        }
        return super.onOptionsItemSelected(item)
    }

    override fun onResume() {
        super.onResume()

        getListData()

    }

    private fun getListData(){

        vm.getList().observe(this) { result ->
            if (result != null) {
                when (result) {
                    is DataResult.Loading -> {
                        showLoading(true)
                    }
                    is DataResult.Success -> {
                        showLoading(false)
                        setListData(result.data)
                    }
                    is DataResult.Error -> {
                        showLoading(false)
                        Toast.makeText(
                            this,
                            "Terjadi kesalahan" + result.error,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }
    }

    private fun setListData(userList: List<DetailStory>) {

        val adapter = MenuAdapter(userList) { value ->
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra(DetailActivity.ID, value.id)
            startActivity(intent)
        }
        binding?.menuRec?.adapter = adapter

    }


    private fun showLoading(isLoading: Boolean) {

        binding?.menuProgbar?.visibility = if (isLoading) View.VISIBLE else View.GONE

    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}