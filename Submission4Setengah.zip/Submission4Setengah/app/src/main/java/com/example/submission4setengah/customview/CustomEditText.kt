package com.example.submission4setengah.customview

import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.AttributeSet
import android.util.Patterns
import android.view.View
import androidx.appcompat.widget.AppCompatEditText
import androidx.core.content.ContextCompat
import com.example.submission4setengah.R

class CustomEditText : AppCompatEditText, TextWatcher {


    private var iconDone: Drawable? = null
    private var flagError: Boolean = false
    private var flagParam: Boolean = false
    private var flagNone: Boolean = false
    private lateinit var errorMsg : String

    constructor(context: Context) : super(context) {
        init()
    }
    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        init()
    }
    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        init()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        textAlignment = View.TEXT_ALIGNMENT_VIEW_START
    }

    private fun showIcon() {
        setButtonDrawables(endOfTheText = iconDone)
    }

    private fun hideIcon() {
        setButtonDrawables()
    }

    private fun setButtonDrawables(
        startOfTheText: Drawable? = null,
        topOfTheText: Drawable? = null,
        endOfTheText: Drawable? = null,
        bottomOfTheText: Drawable? = null
    ){
        setCompoundDrawablesWithIntrinsicBounds(
            startOfTheText,
            topOfTheText,
            endOfTheText,
            bottomOfTheText
        )
    }

    fun blankText(){
        text = null
        flagError = false
        hideIcon()
        clearFocus()
    }

    fun getInfo():Boolean{
        if(text?.length == 0 || !flagParam) return false
        return true
    }

    fun setBlankIcon(){
        iconDone = null
        flagNone = true
        flagParam = true
    }


    private fun init() {

        iconDone = ContextCompat.getDrawable(context, R.drawable.ic_done) as Drawable


        when(inputType-1){
            InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS -> {
                errorMsg = context.getString(R.string.error_email)
            }
            InputType.TYPE_TEXT_VARIATION_PASSWORD -> {
                errorMsg = context.getString(R.string.error_psw)
            }

            else -> errorMsg = "Error"
        }

        addTextChangedListener(this)
    }

    override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
        flagError = true
    }

    override fun afterTextChanged(p0: Editable?) {
        if(flagParam){
            showIcon()
        }
    }

    override fun onTextChanged(
        text: CharSequence?,
        start: Int,
        lengthBefore: Int,
        lengthAfter: Int
    ) {
        super.onTextChanged(text, start, lengthBefore, lengthAfter)

        if(!flagNone) {

            when (inputType - 1) {

                InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS -> {
                    flagParam = paramEmail(text)
                }
                InputType.TYPE_TEXT_VARIATION_PASSWORD -> {
                    flagParam = paramPassword(text.toString())
                }
            }


            if (flagError && !flagParam) {
                error = errorMsg
            } else {
                hideIcon()
            }

        }
    }

    private fun paramPassword(text: String): Boolean {
        if (text.length < 8) return false
        if (text.firstOrNull { it.isDigit() } == null) return false
        if (text.filter { it.isLetter() }.firstOrNull { it.isUpperCase() } == null) return false
        if (text.filter { it.isLetter() }.firstOrNull { it.isLowerCase() } == null) return false
        if (text.firstOrNull { !it.isLetterOrDigit() } == null) return false

        return true
    }

    private fun paramEmail(text: CharSequence?): Boolean {

        if (text.isValidEmail()) return true
        return false
    }

    private fun CharSequence?.isValidEmail() = !isNullOrEmpty() && Patterns.EMAIL_ADDRESS.matcher(this).matches()



}