package com.example.submission4setengah.ui.login

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.submission4setengah.data.remote.response.DetailLogin
import com.example.submission4setengah.data.DataRepo
import com.example.submission4setengah.data.pref.UserStore
import kotlinx.coroutines.launch

class MainViewModel(private val repo: DataRepo, private val pref: UserStore) : ViewModel() {


    fun loginku(value:HashMap<String, String>) = repo.login(value)

    fun registerku(value:HashMap<String, String>) = repo.register(value)

    fun saveStore(value: DetailLogin) {
        viewModelScope.launch {
            pref.saveAll(value, true)
        }
    }

    fun getLogin(): LiveData<Boolean> {
        return pref.getLogin().asLiveData()
    }



}