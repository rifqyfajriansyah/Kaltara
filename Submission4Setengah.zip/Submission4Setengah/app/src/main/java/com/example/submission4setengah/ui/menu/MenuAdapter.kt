package com.example.submission4setengah.ui.menu

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.submission4setengah.data.remote.response.DetailStory
import com.example.submission4setengah.databinding.ListItemBinding

class MenuAdapter(private val userList: List<DetailStory>, private val itemClickListener: (DetailStory)->Unit) : RecyclerView.Adapter<MenuAdapter.ListItemHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListItemHolder {

        val itemBinding = ListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ListItemHolder(itemBinding)

    }

    override fun onBindViewHolder(holder: ListItemHolder, position: Int) {
       holder.bind(userList[position], itemClickListener)
    }

    override fun getItemCount(): Int = userList.size

    inner class ListItemHolder(private val itemBinding: ListItemBinding) : RecyclerView.ViewHolder(itemBinding.root) {
        fun bind(value: DetailStory, itemClickListener: (DetailStory) -> Unit) {

            itemBinding.tvItemName.text = value.name
            Glide.with(itemBinding.root)
                .load(value.photoUrl)
                .into(itemBinding.ivItemPhoto)
            itemBinding.root.setOnClickListener { itemClickListener(value) }

        }
    }
}