package com.example.submission4setengah.ui.add

import android.text.Editable
import androidx.lifecycle.ViewModel
import com.example.submission4setengah.data.DataRepo
import okhttp3.MultipartBody

class AddViewModel (private val repo: DataRepo) : ViewModel() {

    fun postData(image: MultipartBody.Part, desc: String) = repo.postData(image, desc)

}