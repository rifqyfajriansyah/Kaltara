package com.example.submission4setengah.data.pref

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.submission4setengah.data.remote.response.DetailLogin
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "userku")
class UserStore private constructor(private val dataStore: DataStore<Preferences>) {

    private val userId = stringPreferencesKey(USER_ID)
    private val userName = stringPreferencesKey(USER_NAME)
    private val userToken = stringPreferencesKey(USER_TOKEN)
    private val LOGINKEY = booleanPreferencesKey("login_setting")


    fun getSingle(param: String): Flow<String> {
        return dataStore.data.map { preferences ->
            preferences[stringPreferencesKey(param)].toString()
        }
    }

    fun getLogin(): Flow<Boolean> {
        return dataStore.data.map { preferences ->
            preferences[LOGINKEY] ?: false
        }
    }


    suspend fun saveAll(values: DetailLogin, valueLogin: Boolean) {
        dataStore.edit { preferences ->
            preferences[userId] = values.userId.toString()
            preferences[userName] = values.name.toString()
            preferences[userToken] = values.token.toString()
            preferences[LOGINKEY] = valueLogin
        }
    }

    suspend fun clearAll() {
        dataStore.edit { preferences ->
            preferences.clear()
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: UserStore? = null

        fun getInstance(dataStore: DataStore<Preferences>): UserStore {
            return INSTANCE ?: synchronized(this) {
                val instance = UserStore(dataStore)
                INSTANCE = instance
                instance
            }
        }

        const val  USER_ID = "userId"
        const val  USER_NAME = "userName"
        const val  USER_TOKEN = "userToken"

    }

}