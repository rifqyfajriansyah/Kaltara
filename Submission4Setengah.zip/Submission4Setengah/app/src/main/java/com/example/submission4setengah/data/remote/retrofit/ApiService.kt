package com.example.submission4setengah.data.remote.retrofit

import com.example.submission4setengah.data.remote.response.*
import okhttp3.MultipartBody
import retrofit2.http.*

interface ApiService {

    @POST("login")
    suspend fun setLogin(
        @Body body: Map<String, String>
    ): ResponseLogin

    @POST("register")
    suspend fun setRegister(
        @Body body: Map<String, String>
    ): ResponseMessage

    @GET("stories")
    suspend fun getList( @Header("Authorization") token: String): ResponseListStory

    @GET("stories/{id}")
    suspend fun getStory( @Header("Authorization") token: String, @Path("id")id: String): ResponseStory

    @Multipart
    @POST("stories")
    suspend fun postStory(
        @Header("Authorization") token: String,
        @Part file : MultipartBody.Part,
        @Part("description") desc : String
    ): ResponseMessage
}