package com.example.submission4setengah.data.remote.response

import com.google.gson.annotations.SerializedName

data class ResponseMessage(

    @field:SerializedName("error") val error: Boolean,
    @field:SerializedName("message") val message: String

)

data class ResponseLogin(

    @field:SerializedName("error") val error: Boolean,
    @field:SerializedName("message") val message: String,
    @field:SerializedName("loginResult") val result: DetailLogin

)

data class ResponseStory(

    @field:SerializedName("error") val error: Boolean,
    @field:SerializedName("message") val message: String,
    @field:SerializedName("story") val result: DetailStory

)

data class ResponseListStory(

    @field:SerializedName("error") val error: Boolean,
    @field:SerializedName("message") val message: String,
    @field:SerializedName("listStory") val result: List<DetailStory>

)

data class DetailLogin (

    @field:SerializedName("userId") val userId: String?,
    @field:SerializedName("name") val name: String?,
    @field:SerializedName("token") val token: String?
)


data class DetailStory (

    @field:SerializedName("id") val id: String,
    @field:SerializedName("name") val name: String,
    @field:SerializedName("description") val description: String,
    @field:SerializedName("photoUrl") val photoUrl: String,
    @field:SerializedName("createdAt") val createdAt: String,
    @field:SerializedName("lat") val lat: Double,
    @field:SerializedName("lon") val lon: Double

)

