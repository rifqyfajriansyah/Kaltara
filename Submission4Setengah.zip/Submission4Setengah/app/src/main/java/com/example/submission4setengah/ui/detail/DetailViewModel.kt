package com.example.submission4setengah.ui.detail

import androidx.lifecycle.ViewModel
import com.example.submission4setengah.data.DataRepo
import com.example.submission4setengah.data.pref.UserStore

class DetailViewModel (private val repo: DataRepo) : ViewModel() {

    fun getDetal(id:String) = repo.getDetailData(id)

}