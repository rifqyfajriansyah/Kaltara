package com.example.submission4setengah.ui.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import com.bumptech.glide.Glide
import com.example.submission4setengah.data.DataResult
import com.example.submission4setengah.data.remote.response.DetailStory
import com.example.submission4setengah.databinding.ActivityDetailBinding
import com.example.submission4setengah.ui.ViewModelFactory

class DetailActivity : AppCompatActivity() {

    private var _binding: ActivityDetailBinding? = null
    private val binding get() = _binding
    private lateinit var view: View

    private val vm by viewModels<DetailViewModel> {
        ViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityDetailBinding.inflate(layoutInflater)
        view = binding?.root!!
        setContentView(view)

        vm.getDetal(intent.getStringExtra(ID)!!).observe(this){ result->

            if (result != null) {
                when (result) {
                    is DataResult.Loading -> {
                        showLoading(true)
                    }
                    is DataResult.Success -> {
                        showLoading(false)
                        setData(result.data)
                    }
                    is DataResult.Error -> {
                        showLoading(false)
                        Toast.makeText(
                            this,
                            "Terjadi kesalahan" + result.error,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }


    }

    private fun setData(values:DetailStory){

        binding?.apply {
            tvDetailName.text = values.name
            tvDetailDate.text = values.createdAt
            tvDetailDescription.text = values.description
        }

        Glide.with(this)
            .load(values.photoUrl)
            .into(binding?.ivDetailPhoto!!)

    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    private fun showLoading(isLoading: Boolean) {

        binding?.detailProgbar?.visibility = if (isLoading) View.VISIBLE else View.GONE

    }


    companion object{
        const val ID = "idku"
    }
}