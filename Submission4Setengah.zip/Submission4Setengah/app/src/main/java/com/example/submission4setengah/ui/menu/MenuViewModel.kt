package com.example.submission4setengah.ui.menu

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.submission4setengah.data.DataRepo
import com.example.submission4setengah.data.pref.UserStore
import com.example.submission4setengah.data.remote.response.DetailLogin
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MenuViewModel(private val repo: DataRepo, private val pref: UserStore) : ViewModel() {

    fun getList() = repo.getListData()

    fun logout(){
        viewModelScope.launch {
            pref.clearAll()
        }
    }

    fun getLogin(): LiveData<Boolean> {
        return pref.getLogin().asLiveData()
    }



}