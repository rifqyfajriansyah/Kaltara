package com.example.submission4setengah.di

import android.content.Context
import com.example.submission4setengah.data.DataRepo
import com.example.submission4setengah.data.pref.UserStore
import com.example.submission4setengah.data.pref.dataStore
import com.example.submission4setengah.data.remote.retrofit.ApiConfig

object Injection {

    fun provideData(context: Context): DataRepo {
        val pref = UserStore.getInstance(context.applicationContext.dataStore)
        val apiService = ApiConfig.getApiService()
        return DataRepo.getInstance(apiService, pref)
    }

}