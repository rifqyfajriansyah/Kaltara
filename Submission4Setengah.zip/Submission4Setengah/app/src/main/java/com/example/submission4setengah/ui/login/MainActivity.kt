package com.example.submission4setengah.ui.login

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.viewModels
import com.example.submission4setengah.ui.menu.MenuActivity
import com.example.submission4setengah.R
import com.example.submission4setengah.ui.ViewModelFactory
import com.example.submission4setengah.data.DataResult
import com.example.submission4setengah.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private var _binding: ActivityMainBinding? = null
    private val binding get() = _binding
    private lateinit var view: View

    private var isSignUp : Boolean = false

    private val vm by viewModels<MainViewModel> {
        ViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityMainBinding.inflate(layoutInflater)
        view = binding?.root!!
        setContentView(view)


        supportActionBar?.hide()

        binding?.apply {

            edLoginPassword.setBlankIcon()
            edSignupUsername.setBlankIcon()

        }

        binding?.textLoginBawah2?.setOnClickListener(this)
        binding?.imgBackLogin?.setOnClickListener(this)
        binding?.btLogin?.setOnClickListener(this)
        binding?.btSignup?.setOnClickListener(this)

        //showLoading(true)
        //visibilitynya gabisa diubah di motionlayout
        //udah ditambah contraint dan property set sama aja
        //gimana caranya ya

        showLoading(true)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if(isSignUp){
                    onMotionToLogin()
                }else{
                    finish()
                }

            }
        })

        vm.getLogin().observe(this){isLogin : Boolean ->

            showLoading(false)
            if(isLogin){
                val intent = Intent(this, MenuActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
                finish()

            }
        }



    }

    override fun onClick(p0: View?) {

        when(p0?.id){
            R.id.textLoginBawah2 -> onMotionToSignUp()
            R.id.img_back_login -> onMotionToLogin()
            R.id.bt_login ->{



                if(checkLogin()){
                    val valueHas = hashMapOf<String, String>()
                    binding?.apply {

                        valueHas[EMAIL] = edLoginEmail.text.toString()
                        valueHas[PASSWORD] = edLoginPassword.text.toString()
                    }

                    vm.loginku(valueHas).observe(this@MainActivity){ result ->
                        if (result != null) {
                            when (result) {
                                is DataResult.Loading -> {
                                    showLoading(true)
                                }
                                is DataResult.Success -> {
                                    showLoading(false)
                                    vm.saveStore(result.data)

                                }
                                is DataResult.Error -> {
                                    showLoading(false)
                                    showToast(this.getString(R.string.error_message))
                                }
                            }
                        }
                    }


                }else{
                    showToast(this.getString(R.string.fail_message))
                }

            }

            R.id.bt_signup ->{

                if(checkSignUp()){

                    val valueHas = hashMapOf<String, String>()
                    binding?.apply {

                        valueHas[USERNAME] = edSignupUsername.text.toString()
                        valueHas[EMAIL] = edSignupEmail.text.toString()
                        valueHas[PASSWORD] = edSignupPassword.text.toString()

                    }

                    vm.registerku(valueHas).observe(this@MainActivity){ result ->
                        if (result != null) {
                            when (result) {
                                is DataResult.Loading -> {
                                    showLoading(true)
                                }
                                is DataResult.Success -> {
                                    showLoading(false)
                                    showToast(this.getString(R.string.succes_signup))

                                    onMotionToLogin(true)

                                }
                                is DataResult.Error -> {
                                    showLoading(false)
                                    showToast(this.getString(R.string.fail_message))
                                }
                            }
                        }
                    }


                }else{
                    showToast(this.getString(R.string.fail_message))
                }

            }

        }
    }

    private fun showToast(message:String){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }


    private fun checkLogin():Boolean{

        binding?.apply {
            if(!edLoginEmail.getInfo() || !edLoginPassword.getInfo()) return false
        }
        return true

    }

    private fun checkSignUp():Boolean{

        binding?.apply {
            if(!edSignupUsername.getInfo() || !edSignupEmail.getInfo() || !edSignupPassword.getInfo()) return false
        }

        return true

    }

    private fun onMotionToLogin(isSucces : Boolean = false){
        isSignUp = false
        binding?.apply {

            if(isSucces){
                edLoginEmail.text = edSignupEmail.text
            }

            motionMain.transitionToState(R.id.start)
            edSignupPassword.blankText()
            edSignupEmail.blankText()
            edSignupUsername.blankText()
            view.hideKeyboard()
        }
    }

    private fun onMotionToSignUp(){
        isSignUp = true
        binding?.apply {
            motionMain.transitionToState(R.id.end)
            edLoginEmail.blankText()
            edLoginPassword.blankText()
            view.hideKeyboard()
        }
    }

    private fun View.hideKeyboard() {
        val inputManager = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        inputManager.hideSoftInputFromWindow(windowToken, 0)
    }

    private fun showLoading(isLoading: Boolean) {

        if(isSignUp){

            if(isLoading) {
                binding?.motionMain?.transitionToState(R.id.isLoadingSignUp)
            }else {
                binding?.motionMain?.transitionToState(R.id.end)
            }

        }else{
            if(isLoading) {
                binding?.motionMain?.transitionToState(R.id.isLoading)
            }else {
                binding?.motionMain?.transitionToState(R.id.start)
            }
        }


    }


    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    companion object{
        const val USERNAME = "name"
        const val EMAIL = "email"
        const val PASSWORD = "password"

    }



}