package com.example.submission4setengah.data

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.liveData
import androidx.lifecycle.map
import com.example.submission4setengah.data.pref.UserStore
import com.example.submission4setengah.data.remote.response.DetailLogin
import com.example.submission4setengah.data.remote.response.DetailStory
import com.example.submission4setengah.data.remote.response.ResponseMessage
import com.example.submission4setengah.data.remote.retrofit.ApiService
import kotlinx.coroutines.flow.first
import okhttp3.MultipartBody

class DataRepo private constructor(private val apiService: ApiService, private val pref: UserStore){

    private val valueToken = pref.getSingle(UserStore.USER_TOKEN)

    fun login(value: HashMap<String, String>): LiveData<DataResult<DetailLogin>> = liveData {

        val responselogin = MutableLiveData<DetailLogin>()

        emit(DataResult.Loading)
        try {

            val response = apiService.setLogin(value)
            responselogin.value = response.result

        }catch (e: Throwable) {
            /*if(e is HttpException) {
                emit(DataResult.Error("Gaggal"))
            }else emit(DataResult.Error(e.message.toString()))*/
            //cara membaca response body saat terjadi error gimana ya
            emit(DataResult.Error(e.message.toString()))
        }

        emitSource(responselogin.map{ DataResult.Success(it) })

    }

    fun register(value: HashMap<String, String>): LiveData<DataResult<ResponseMessage>> = liveData {

        val responselogin = MutableLiveData<ResponseMessage>()

        emit(DataResult.Loading)
        try {
            val response = apiService.setRegister(value)
            responselogin.value = response

            emitSource(responselogin.map{ DataResult.Success(it) })

        }catch (e: Throwable) {

                emit(DataResult.Error(e.message.toString()))

        }

    }

    fun getListData():LiveData<DataResult<List<DetailStory>>> = liveData {


        val responseList = MutableLiveData<List<DetailStory>>()

        emit(DataResult.Loading)
        try {
            val response= apiService.getList(getAuth(pref.getSingle(UserStore.USER_TOKEN).first()))
            responseList.value = response.result
            emitSource(responseList.map { DataResult.Success(it) })


        }catch (e: Exception){
            emit(DataResult.Error(e.message.toString()))
        }


    }

    fun getDetailData(id:String):LiveData<DataResult<DetailStory>> = liveData {

        val responseList = MutableLiveData<DetailStory>()

        emit(DataResult.Loading)
        try {
            val response= apiService.getStory(getAuth(pref.getSingle(UserStore.USER_TOKEN).first()), id)
            responseList.value = response.result
            emitSource(responseList.map { DataResult.Success(it) })

        }catch (e: Exception){
            emit(DataResult.Error(e.message.toString()))
        }


    }

    fun postData(values:MultipartBody.Part, desc: String) : LiveData<DataResult<ResponseMessage>> = liveData {
        val responseData = MutableLiveData<ResponseMessage>()

        emit(DataResult.Loading)
        try {
            val response = apiService.postStory(getAuth(valueToken.first()), values, desc)
            responseData.value = response
            emitSource(responseData.map { DataResult.Success(it) })
        }catch (e:Exception){
            emit(DataResult.Error(e.message.toString()))
        }

    }

    private fun getAuth(value:String):String{
        return "Bearer $value"
    }



    companion object {
        @Volatile
        private var instance: DataRepo? = null
        fun getInstance(
            apiService: ApiService, pref:UserStore
        ): DataRepo =
            instance ?: synchronized(this) {
                instance ?: DataRepo(apiService, pref)
            }.also { instance = it }
    }

}